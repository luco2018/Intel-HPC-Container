cat << EOF > params.24x24x24x24
prompt 0
nx 24
ny 24
nz 24
nt 24
EOF
cat params.rest >> params.24x24x24x24 

